from django.shortcuts import render
from datetime import datetime, timedelta

def countdown_view(request):

    target_time = datetime.now() + timedelta(hours=2)
    target_time_str = target_time.strftime('%Y-%m-%dT%H:%M:%S')
    return render(request, 'index.html', {'target_time': target_time_str})
